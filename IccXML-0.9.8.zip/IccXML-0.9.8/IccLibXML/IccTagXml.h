/** @file
File:       IccTagXml.h

Contains:   Header for implementation of CIccTagXml class and
creation factories

Version:    V1

Copyright:  � see ICC Software License
*/


/*
 * The ICC Software License, Version 0.2
 *
 *
 * Copyright (c) 2003-2010 The International Color Consortium. All rights 
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. In the absence of prior written permission, the names "ICC" and "The
 *    International Color Consortium" must not be used to imply that the
 *    ICC organization endorses or promotes products derived from this
 *    software.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE INTERNATIONAL COLOR CONSORTIUM OR
 * ITS CONTRIBUTING MEMBERS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the The International Color Consortium. 
 *
 *
 * Membership in the ICC is encouraged when this software is used for
 * commercial purposes. 
 *
 *  
 * For more information on The International Color Consortium, please
 * see <http://www.color.org/>.
 *  
 * 
 */

#ifndef _ICCTAGXML_H
#define _ICCTAGXML_H
#include "IccTag.h"
#include "IccTagMPE.h"
#include "IccXmlConfig.h"
#include <libxml/parser.h>
#include <libxml/tree.h>

class CIccTagXml : public IIccExtensionTag
{
public:
  virtual ~CIccTagXml(void) {}

  virtual const char *GetExtClassName() const { return "CIccTagXml"; }
  virtual const char *GetExtDerivedClassName() const { return ""; }

  virtual bool ToXml(std::string &xml, std::string blanks="") = 0;
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr) = 0;
};

class CIccTagXmlUnknown : public CIccTagUnknown, public CIccTagXml
{
public:
  CIccTagXmlUnknown(icTagTypeSignature nType) { m_nType = nType; }
  virtual ~CIccTagXmlUnknown() {}

  virtual const char *GetClassName() const { return "CIccTagXmlUnknown"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlText : public CIccTagText, public CIccTagXml
{
public:
  CIccTagXmlText() : CIccTagText() {}
  CIccTagXmlText(const CIccTagXmlText &ITT) : CIccTagText(ITT) {}
  virtual ~CIccTagXmlText() {}

  virtual CIccTag* NewCopy() const {return new CIccTagXmlText(*this);}

  virtual const char *GetClassName() const { return "CIccTagXmlText"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlTextDescription : public CIccTagTextDescription, public CIccTagXml
{
public:
  CIccTagXmlTextDescription() : CIccTagTextDescription() {}
  CIccTagXmlTextDescription(const CIccTagXmlTextDescription &ITTD) : CIccTagTextDescription(ITTD) {}
  virtual ~CIccTagXmlTextDescription() {}

  virtual CIccTag* NewCopy() const {return new CIccTagXmlTextDescription(*this);}

  virtual const char *GetClassName() const { return "CIccTagXmlTextDescription"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlSignature : public CIccTagSignature, public CIccTagXml
{
public:
  virtual ~CIccTagXmlSignature() {}

  virtual const char *GetClassName() const { return "CIccTagXmlSignature"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlNamedColor2 : public CIccTagNamedColor2, public CIccTagXml
{
public:
  virtual ~CIccTagXmlNamedColor2() {}

  virtual const char *GetClassName() const { return "CIccTagXmlNamedColor2"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlXYZ : public CIccTagXYZ, public CIccTagXml
{
public:
  virtual ~CIccTagXmlXYZ() {}

  virtual const char *GetClassName() const { return "CIccTagXmlXYZ"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlChromaticity : public CIccTagChromaticity, public CIccTagXml
{
public:
  virtual ~CIccTagXmlChromaticity() {}

  virtual const char *GetClassName() const { return "CIccTagXmlChromaticity"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

template <class T, icTagTypeSignature Tsig>
class CIccTagXmlFixedNum : public CIccTagFixedNum<T, Tsig>, public CIccTagXml
{
public:
  virtual ~CIccTagXmlFixedNum() {}

  virtual const char *GetClassName() const;

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

typedef CIccTagXmlFixedNum<icS15Fixed16Number, icSigS15Fixed16ArrayType> CIccTagXmlS15Fixed16;
typedef CIccTagFixedNum<icU16Fixed16Number, icSigU16Fixed16ArrayType> CIccTagXmlU16Fixed16;


template <class T, icTagTypeSignature Tsig>
class CIccTagXmlNum : public CIccTagNum<T, Tsig>, public CIccTagXml
{
public:
  virtual ~CIccTagXmlNum() {}

  virtual const char *GetClassName() const;

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

typedef CIccTagNum<icUInt8Number, icSigUInt8ArrayType> CIccTagXmlUInt8;
typedef CIccTagNum<icUInt16Number, icSigUInt16ArrayType> CIccTagXmlUInt16;
typedef CIccTagNum<icUInt32Number, icSigUInt32ArrayType> CIccTagXmlUInt32;
typedef CIccTagNum<icUInt64Number, icSigUInt64ArrayType> CIccTagXmlUInt64;

class CIccTagXmlMeasurement : public CIccTagMeasurement, public CIccTagXml
{
public:
  virtual ~CIccTagXmlMeasurement() {}

  virtual const char *GetClassName() const { return "CIccTagXmlMeasurement"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlMultiLocalizedUnicode : public CIccTagMultiLocalizedUnicode, public CIccTagXml
{
public:
  virtual ~CIccTagXmlMultiLocalizedUnicode() {}

  virtual const char *GetClassName() const { return "CIccTagXmlMultiLocalizedUnicode"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlData : public CIccTagData, public CIccTagXml
{
public:
  virtual ~CIccTagXmlData() {}

  virtual const char *GetClassName() const { return "CIccTagXmlData"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlDateTime : public CIccTagDateTime, public CIccTagXml
{
public:
  virtual ~CIccTagXmlDateTime() {}

  virtual const char *GetClassName() const { return "CIccTagXmlDateTime"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlColorantOrder : public CIccTagColorantOrder, public CIccTagXml
{
public:
  virtual ~CIccTagXmlColorantOrder() {}

  virtual const char *GetClassName() const { return "CIccTagXmlColorantOrder"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlColorantTable : public CIccTagColorantTable, public CIccTagXml
{
public:
  virtual ~CIccTagXmlColorantTable() {}

  virtual const char *GetClassName() const { return "CIccTagXmlColorantTable"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlViewingConditions : public CIccTagViewingConditions, public CIccTagXml
{
public:
  virtual ~CIccTagXmlViewingConditions() {}

  virtual const char *GetClassName() const { return "CIccTagXmlViewingConditions"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlProfileSeqDesc : public CIccTagProfileSeqDesc, public CIccTagXml
{
public:
  virtual ~CIccTagXmlProfileSeqDesc() {}

  virtual const char *GetClassName() const { return "CIccTagXmlProfileSeqDesc"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlResponseCurveSet16 : public CIccTagResponseCurveSet16, public CIccTagXml
{
public:
  virtual ~CIccTagXmlResponseCurveSet16() {}

  virtual const char *GetClassName() const { return "CIccTagXmlResponseCurveSet16"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

 class CIccCurveXml : public CIccTagXml
 {
 public:
   virtual ~CIccCurveXml() {}
 
   virtual const char *GetExtDerivedClassName() const { return "CIccCurveXml"; }
 
   virtual bool ToXml(std::string &xml, icConvertType nType, std::string blanks) = 0;
   virtual bool ParseXml(xmlNode *pNode, icConvertType nType, std::string &parseStr) = 0;
 };
 
class CIccTagXmlCurve : public CIccTagCurve, public CIccCurveXml
{
public:
  virtual ~CIccTagXmlCurve() {}

  virtual const char *GetClassName() const { return "CIccTagXmlCurve"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ToXml(std::string &xml, icConvertType nType, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
  virtual bool ParseXml(xmlNode *pNode, icConvertType nType, std::string &parseStr);
};

class CIccTagXmlParametricCurve : public CIccTagParametricCurve, public CIccCurveXml
{
public:
  virtual ~CIccTagXmlParametricCurve() {}

  virtual const char *GetClassName() const { return "CIccTagXmlParametricCurve"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ToXml(std::string &xml, icConvertType nType, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
   virtual bool ParseXml(xmlNode *pNode, icConvertType nType, std::string &parseStr);
};

class CIccTagXmlLutAtoB : public CIccTagLutAtoB, public CIccTagXml
{
public:
  virtual ~CIccTagXmlLutAtoB() {}

  virtual const char *GetClassName() const { return "CIccTagXmlLutAtoB"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlLutBtoA : public CIccTagLutBtoA, public CIccTagXml
{
public:
  virtual ~CIccTagXmlLutBtoA() {}

  virtual const char *GetClassName() const { return "CIccTagXmlLutBtoA"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlLut8 : public CIccTagLut8, public CIccTagXml
{
public:
  virtual ~CIccTagXmlLut8() {}

  virtual const char *GetClassName() const { return "CIccTagXmlLut8"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlLut16 : public CIccTagLut16, public CIccTagXml
{
public:
  virtual ~CIccTagXmlLut16() {}

  virtual const char *GetClassName() const { return "CIccTagXmlLut16"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlMultiProcessElement : public CIccTagMultiProcessElement, public CIccTagXml
{
public:
  virtual ~CIccTagXmlMultiProcessElement() {}

  virtual const char *GetClassName() const { return "CIccTagXmlMultiProcessElement"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
 
protected:
  bool ParseElement(xmlNode *pNode, std::string &parseStr);
  CIccMultiProcessElement *CreateElement(const icChar *szElementNodeName);

};

class CIccTagXmlProfileSequenceId : public CIccTagProfileSequenceId, public CIccTagXml
{
public:
  virtual ~CIccTagXmlProfileSequenceId() {}

  virtual const char *GetClassName() const { return "CIccTagXmlProfileSequenceId"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};

class CIccTagXmlDict : public CIccTagDict, public CIccTagXml
{
public:
  virtual ~CIccTagXmlDict() {}

  virtual const char *GetClassName() const { return "CIccTagXmlDict"; }

  virtual IIccExtensionTag *GetExtension() { return this; }

  virtual bool ToXml(std::string &xml, std::string blanks="");
  virtual bool ParseXml(xmlNode *pNode, std::string &parseStr);
};
#endif //_ICCTAGXML_H
